#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define BUFFER_SIZE 1048576

struct
{
    char *filename;
    char *filepath;
    int fileNumber;
} typedef PPMFile;

struct
{
    PPMFile *files;
    int size;
} typedef PPMFiles;

PPMFiles getFileNames(char *directoryName)
{
    DIR *d = opendir(directoryName);
    if (d != NULL)
    {
        struct dirent *dir;
        PPMFiles ppmFiles;
        ppmFiles.size = 0;
        ppmFiles.files = NULL;

        while ((dir = readdir(d)) != NULL)
        {
            int len = strlen(dir->d_name);
            // Check for PPM file extension.
            if (len > 4 && strcmp(dir->d_name + len - 4, ".ppm") == 0)
            {
                // Allocate/expand memory for the new PPMFile entry.
                ppmFiles.files = realloc(ppmFiles.files, (ppmFiles.size + 1) * sizeof(PPMFile));
                assert(ppmFiles.files != NULL);

                // Store filename.
                ppmFiles.files[ppmFiles.size].filename = strdup(dir->d_name);
                assert(ppmFiles.files[ppmFiles.size].filename != NULL);

                // Extract and store the file number.
                char fileNumStr[5] = {0};            // Buffer for the file number string.
                strncpy(fileNumStr, dir->d_name, 4); // Copy the file number part of the filename.
                ppmFiles.files[ppmFiles.size].fileNumber = atoi(fileNumStr);

                // Construct and store the filepath.
                ppmFiles.files[ppmFiles.size].filepath = malloc(strlen(directoryName) + strlen(dir->d_name) + 2);
                assert(ppmFiles.files[ppmFiles.size].filepath != NULL);
                sprintf(ppmFiles.files[ppmFiles.size].filepath, "%s/%s", directoryName, dir->d_name);

                // Increment the total file count.
                ppmFiles.size++;
            }
        }

        closedir(d);
        return ppmFiles;
    }
    else
    {
        printf("An error has occurred\n");
        exit(1);
    }
}

size_t loadPPMFileData(PPMFile file, char *buffer)
{
    // Open the PPM file.
    FILE *f = fopen(file.filepath, "rb");
    if (f == NULL)
    {
        perror("Error opening file");
        return 0;
    }

    // Read up to 1 MB of data from the file into the provided buffer.
    size_t bytesRead = fread(buffer, 1, BUFFER_SIZE, f);
    if (bytesRead == 0 && !feof(f))
    {
        // Handle the read error (not end-of-file).
        perror("Error reading file");
    }

    fclose(f);        // Close the file.
    return bytesRead; // Return the number of bytes read.
}